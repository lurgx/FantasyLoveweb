-- Juego 3D con console.mini3d. Usa: console.menu, console.stick, console.accel, L/R, logros, guardado.
local game = {}
local M3 = console.mini3d
local cam, ship, obs, gems, speed, dist, score, lives, state, best, spawnT, menu, tilt, flash, got
local font, big
local HW, HH = 7, 4.5

local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

local function reset()
  ship = { x = 0, y = 0 }
  obs, gems = {}, {}
  speed, dist, score, lives, spawnT, flash, got = 28, 0, 0, 3, 0, 0, 0
  state = "play"
end

function game.load()
  font = love.graphics.newFont(10, "mono")
  big = love.graphics.newFont(22, "mono")
  cam = M3.camera(480, 272, 300)
  cam.far = 140
  best = console.load().best or 0
  tilt = false
  menu = console.menu({ "Jugar", "Control: stick / cruceta", "Salir" })
  state = "menu"
end

local function finish()
  state = "over"
  if score > best then best = math.floor(score); console.save({ best = best }) end
end

function game.update(dt)
  if flash > 0 then flash = flash - dt end
  if state == "menu" then
    local r = menu:update()
    if r == 1 then reset()
    elseif r == 2 then
      tilt = not tilt
      menu.items[2] = tilt and "Control: inclinar el movil" or "Control: stick / cruceta"
    elseif r == 3 or r == 0 then console.exit() end
    return
  elseif state == "over" then
    if console.btnp("a") then reset() elseif console.btnp("b") then state = "menu" end
    return
  end

  local dx, dy = console.stick()
  if console.btn("left") then dx = dx - 1 end
  if console.btn("right") then dx = dx + 1 end
  if console.btn("up") then dy = dy - 1 end
  if console.btn("down") then dy = dy + 1 end
  if tilt then
    local ax, ay = console.accel()
    dx = dx + ax * 2.5; dy = dy - ay * 2.5
  end
  ship.x = clamp(ship.x + dx * 12 * dt, -HW + 1, HW - 1)
  ship.y = clamp(ship.y - dy * 12 * dt, -HH + 0.8, HH - 0.8)

  local target = 28 + dist * 0.004
  if console.btn("r") then target = target + 25 end
  if console.btn("l") then target = target * 0.6 end
  speed = speed + (target - speed) * math.min(1, dt * 3)
  dist = dist + speed * dt
  score = score + speed * dt * 0.5
  if score >= 500 then console.unlock("nav500") end
  if score >= 2000 then console.unlock("nav2000") end

  spawnT = spawnT - dt
  if spawnT <= 0 then
    spawnT = math.max(0.25, 0.9 - dist * 0.0004)
    obs[#obs + 1] = { x = love.math.random() * (2 * HW - 2) - (HW - 1), y = love.math.random() * (2 * HH - 1.6) - (HH - 0.8),
                      z = 130, s = 1.5 + love.math.random() * 1.5 }
    if love.math.random() < 0.5 then
      gems[#gems + 1] = { x = love.math.random() * (2 * HW - 2) - (HW - 1), y = love.math.random() * (2 * HH - 1.6) - (HH - 0.8), z = 145 }
    end
  end
  for i = #obs, 1, -1 do
    local o = obs[i]
    o.z = o.z - speed * dt
    if o.z < -2 then table.remove(obs, i)
    elseif math.abs(o.z - 8) < o.s / 2 + 0.8 and math.abs(o.x - ship.x) < o.s / 2 + 0.8 and math.abs(o.y - ship.y) < o.s / 2 + 0.6 then
      table.remove(obs, i); lives = lives - 1; flash = 0.4
      if lives <= 0 then finish() return end
    end
  end
  for i = #gems, 1, -1 do
    local g = gems[i]
    g.z = g.z - speed * dt
    if g.z < -2 then table.remove(gems, i)
    elseif math.abs(g.z - 8) < 1.6 and math.abs(g.x - ship.x) < 1.4 and math.abs(g.y - ship.y) < 1.2 then
      table.remove(gems, i); score = score + 100; got = got + 1
      if got >= 10 then console.unlock("gems10") end
    end
  end
  cam.x = ship.x * 0.6; cam.y = ship.y * 0.6 + 0.4
end

function game.draw()
  love.graphics.setColor(0.02, 0.02, 0.08); love.graphics.rectangle("fill", 0, 0, 480, 272)
  if state == "menu" then
    love.graphics.setFont(big); love.graphics.setColor(0.5, 0.85, 1)
    love.graphics.printf("STAR TUNNEL 3D", 0, 60, 480, "center")
    love.graphics.setFont(font); menu:draw(240, 130, 220)
    love.graphics.setColor(1, 1, 1, 0.6); love.graphics.printf("Record " .. best, 0, 240, 480, "center")
    return
  end
  love.graphics.setLineWidth(1)
  for k = 0, 11 do
    local z = k * 12 - dist % 12
    if z > 1 then
      love.graphics.setColor(0.3, 0.7, 1, 0.65 * (1 - z / 150))
      M3.ring(cam, z, HW, HH)
    end
  end
  love.graphics.setColor(0.2, 0.5, 0.9, 0.35)
  for _, cx in ipairs({ -HW, HW }) do
    for _, cy in ipairs({ -HH, HH }) do M3.line(cam, cx, cy, 1, cx, cy, 140) end
  end
  local faces = {}
  local function add(list) for _, f in ipairs(list) do faces[#faces + 1] = f end end
  for _, o in ipairs(obs) do add(M3.box(o.x, o.y, o.z, o.s, o.s, o.s, { 1, 0.3, 0.3 })) end
  for _, g in ipairs(gems) do add(M3.box(g.x, g.y, g.z, 0.8, 0.8, 0.8, { 1, 0.9, 0.2 })) end
  add(M3.box(ship.x, ship.y, 8, 1.2, 0.5, 2.2, { 0.6, 0.8, 1 }))
  add(M3.box(ship.x, ship.y, 8.3, 2.8, 0.15, 0.8, { 0.3, 0.5, 1 }))
  M3.render(cam, faces, nil, true)
  love.graphics.setFont(font); love.graphics.setColor(1, 1, 1)
  love.graphics.print("Puntos " .. math.floor(score) .. "   Vidas " .. lives .. "   Vel " .. math.floor(speed) .. "   Gemas " .. got, 10, 8)
  if flash > 0 then love.graphics.setColor(1, 0, 0, flash); love.graphics.rectangle("fill", 0, 0, 480, 272) end
  if state == "over" then
    love.graphics.setColor(0, 0, 0, 0.65); love.graphics.rectangle("fill", 120, 100, 240, 70, 8, 8)
    love.graphics.setColor(1, 1, 1)
    love.graphics.printf("Fin del vuelo\nA: otra vez     B: menu", 120, 115, 240, "center")
  end
end

function game.saveState()
  return { ship = ship, obs = obs, gems = gems, speed = speed, dist = dist, score = score, lives = lives, spawnT = spawnT, got = got }
end
function game.loadState(t)
  ship, obs, gems, speed, dist, score, lives, spawnT, got = t.ship, t.obs, t.gems, t.speed, t.dist, t.score, t.lives, t.spawnT, t.got
  state, flash = "play", 0
end

return game
