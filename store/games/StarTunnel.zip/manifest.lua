return {
  name = "Star Tunnel 3D", author = "Tu nombre", version = "1.0", price = 4,
  description = "Vuela por un tunel en 3D esquivando bloques. Stick/cruceta, L frena, R acelera",
  resolution = { 480, 272 },
  icon = "icon.png", preview = { frames = 8, fps = 6 },
  color = { 0.3, 0.7, 1 },
  achievements = {
    nav500  = { name = "Navegante",   stars = 1 },
    nav2000 = { name = "Piloto",      stars = 2 },
    gems10  = { name = "Cazagemas",   stars = 2 },
  },
}
