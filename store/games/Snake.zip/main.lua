local game = {}
local cols, rows, C = 16, 14, 16
local snake, dir, nd, food, timer, alive, score, best

local function spawn()
  repeat
    food = { x = love.math.random(0, cols - 1), y = love.math.random(0, rows - 1) }
    local free = true
    for _, s in ipairs(snake) do if s.x == food.x and s.y == food.y then free = false end end
  until free
end

function game.load()
  best = console.load().best or 0
  snake = { {x = 8, y = 7}, {x = 7, y = 7}, {x = 6, y = 7} }
  dir, nd, timer, alive, score = {1, 0}, {1, 0}, 0, true, 0
  spawn()
end

local function step()
  dir = nd
  local h = snake[1]
  local nx, ny = h.x + dir[1], h.y + dir[2]
  if nx < 0 or ny < 0 or nx >= cols or ny >= rows then alive = false; return end
  for _, s in ipairs(snake) do if s.x == nx and s.y == ny then alive = false; return end end
  table.insert(snake, 1, { x = nx, y = ny })
  if nx == food.x and ny == food.y then
    score = score + 1
    if score > best then best = score; console.save({ best = best }) end
    if score >= 5 then console.unlock("score5") end
    spawn()
  else
    table.remove(snake)
  end
end

function game.update(dt)
  if not alive then if console.btnp("a") then game.load() end return end
  if console.btn("left") and dir[1] == 0 then nd = {-1, 0} end
  if console.btn("right") and dir[1] == 0 then nd = {1, 0} end
  if console.btn("up") and dir[2] == 0 then nd = {0, -1} end
  if console.btn("down") and dir[2] == 0 then nd = {0, 1} end
  timer = timer + dt
  if timer > 0.12 then timer = 0; step() end
end

function game.draw()
  love.graphics.setColor(0.05, 0.1, 0.05)
  love.graphics.rectangle("fill", 0, 0, 256, 224)
  love.graphics.setColor(1, 0.3, 0.3)
  love.graphics.rectangle("fill", food.x * C + 2, food.y * C + 2, C - 4, C - 4)
  love.graphics.setColor(0.3, 1, 0.4)
  for _, s in ipairs(snake) do love.graphics.rectangle("fill", s.x * C + 1, s.y * C + 1, C - 2, C - 2) end
  love.graphics.setColor(1, 1, 1)
  love.graphics.print("Puntos " .. score .. "  Record " .. best, 4, 2)
  if not alive then love.graphics.printf("Fin - pulsa A", 0, 105, 256, "center") end
end

return game
