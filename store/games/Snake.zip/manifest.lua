return {
  name = "Snake Lite", author = "Tu nombre", version = "1.0", description = "Come manzanas y no te choques", price = 3,
  icon = "icon.png", preview = { frames = 8, fps = 6 },
  color = {0.2, 0.8, 0.3},
  achievements = { score5 = { name = "Serpiente hambrienta", stars = 1 } },
}
