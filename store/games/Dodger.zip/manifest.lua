return {
  name = "Dodger", author = "Tu nombre", version = "1.0", description = "Esquiva los bloques que caen", price = 2,
  icon = "icon.png", preview = { frames = 8, fps = 6 },
  color = {0.9, 0.3, 0.5},
  achievements = { survive20 = { name = "Superviviente", stars = 2 } },
}
