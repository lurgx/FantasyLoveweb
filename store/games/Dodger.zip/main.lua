local game = {}
local p, blocks, spawnT, time, alive

function game.load() p = { x = 120 }; blocks = {}; spawnT = 0; time = 0; alive = true end

function game.update(dt)
  if not alive then if console.btnp("a") then game.load() end return end
  time = time + dt
  if console.btn("left") then p.x = p.x - 130 * dt end
  if console.btn("right") then p.x = p.x + 130 * dt end
  p.x = math.max(0, math.min(240, p.x))
  spawnT = spawnT - dt
  if spawnT <= 0 then
    spawnT = math.max(0.15, 0.6 - time * 0.01)
    blocks[#blocks + 1] = { x = love.math.random(0, 240), y = -16, v = 60 + time * 3 }
  end
  for i = #blocks, 1, -1 do
    local b = blocks[i]
    b.y = b.y + b.v * dt
    if b.y > 224 then table.remove(blocks, i)
    elseif b.y > 184 and b.y < 216 and math.abs(b.x - p.x) < 14 then alive = false end
  end
  if time >= 20 then console.unlock("survive20") end
end

function game.draw()
  love.graphics.setColor(0.08, 0.05, 0.12)
  love.graphics.rectangle("fill", 0, 0, 256, 224)
  love.graphics.setColor(1, 0.4, 0.4)
  for _, b in ipairs(blocks) do love.graphics.rectangle("fill", b.x, b.y, 16, 16) end
  love.graphics.setColor(0.4, 0.8, 1)
  love.graphics.rectangle("fill", p.x, 200, 16, 16)
  love.graphics.setColor(1, 1, 1)
  love.graphics.print(string.format("Tiempo %.1f", time), 4, 2)
  if not alive then love.graphics.printf("Fin - pulsa A", 0, 105, 256, "center") end
end

return game
