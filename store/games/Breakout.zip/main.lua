-- Izq/Der mover la pala, A lanzar la bola
local game = {}
local pad, ball, bricks, lives, score, state, best

function game.load()
  best = console.load().best or 0
  pad = { x = 108, w = 40 }
  ball = { x = 128, y = 196, vx = 70, vy = -120, r = 3, stuck = true }
  bricks = {}
  for r = 0, 4 do for c = 0, 7 do bricks[#bricks + 1] = { x = 4 + c * 31, y = 24 + r * 13, alive = true, r = r } end end
  lives, score, state = 3, 0, "play"
end

local function finish(s)
  state = s
  if score > best then best = score; console.save({ best = best }) end
end

function game.update(dt)
  if state ~= "play" then if console.btnp("a") then game.load() end return end
  if console.btn("left") then pad.x = pad.x - 150 * dt end
  if console.btn("right") then pad.x = pad.x + 150 * dt end
  pad.x = math.max(0, math.min(256 - pad.w, pad.x))
  if ball.stuck then
    ball.x, ball.y = pad.x + pad.w / 2, 196
    if console.btnp("a") then ball.stuck = false; ball.vx = 70; ball.vy = -120 end
    return
  end
  ball.x = ball.x + ball.vx * dt; ball.y = ball.y + ball.vy * dt
  if ball.x < ball.r then ball.x = ball.r; ball.vx = -ball.vx end
  if ball.x > 256 - ball.r then ball.x = 256 - ball.r; ball.vx = -ball.vx end
  if ball.y < ball.r then ball.y = ball.r; ball.vy = -ball.vy end
  if ball.vy > 0 and ball.y + ball.r >= 204 and ball.y + ball.r <= 214 and ball.x >= pad.x and ball.x <= pad.x + pad.w then
    ball.vx = (ball.x - (pad.x + pad.w / 2)) / (pad.w / 2) * 130
    ball.vy = -math.abs(ball.vy)
  end
  local left = 0
  for _, b in ipairs(bricks) do
    if b.alive then
      if ball.x > b.x and ball.x < b.x + 28 and ball.y > b.y and ball.y < b.y + 10 then
        b.alive = false; ball.vy = -ball.vy * 1.02; score = score + 10
        if score >= 100 then console.unlock("score100") end
      else left = left + 1 end
    end
  end
  if left == 0 then console.unlock("clear"); finish("win"); return end
  if ball.y > 230 then
    lives = lives - 1
    if lives <= 0 then finish("over") else ball.stuck = true end
  end
end

function game.draw()
  love.graphics.setColor(0.05, 0.06, 0.12); love.graphics.rectangle("fill", 0, 0, 256, 224)
  local cols = { {1,0.3,0.3}, {1,0.6,0.2}, {1,0.9,0.2}, {0.4,0.9,0.4}, {0.4,0.6,1} }
  for _, b in ipairs(bricks) do
    if b.alive then love.graphics.setColor(cols[b.r + 1]); love.graphics.rectangle("fill", b.x, b.y, 28, 10) end
  end
  love.graphics.setColor(0.8, 0.9, 1); love.graphics.rectangle("fill", pad.x, 204, pad.w, 6)
  love.graphics.setColor(1, 1, 1); love.graphics.circle("fill", ball.x, ball.y, ball.r)
  love.graphics.print("Puntos " .. score .. "  Vidas " .. lives .. "  Record " .. best, 4, 4)
  if state ~= "play" then
    love.graphics.printf(state == "win" and "¡Ganaste! A: otra vez" or "Fin - A: reintentar", 0, 105, 256, "center")
  end
end

return game
