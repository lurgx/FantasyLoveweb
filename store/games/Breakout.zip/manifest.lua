return {
  name = "Breakout", author = "Tu nombre", version = "1.0", price = 2,
  description = "Rompe todos los ladrillos con la bola",
  icon = "icon.png", preview = { frames = 8, fps = 6 },
  color = {0.95, 0.5, 0.2},
  achievements = {
    score100 = { name = "Rompe ladrillos", stars = 1 },
    clear    = { name = "Tablero limpio",  stars = 2 },
  },
}
